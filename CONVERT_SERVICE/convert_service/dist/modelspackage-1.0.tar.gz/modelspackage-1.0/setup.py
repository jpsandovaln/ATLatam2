from setuptools import setup
setup(
    name="modelspackage",
    version="1.0",
    description="Paquete de modelos de ffmpeg",
    author="Matias",
    packages=["models", "models.ffmpeg"]

)
